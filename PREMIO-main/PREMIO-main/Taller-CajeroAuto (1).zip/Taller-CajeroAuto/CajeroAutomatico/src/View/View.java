
package View;

import Entity.Metodos;




public class View {
    public static void main(String[] args) {
        Metodos metodos=new Metodos();
        metodos.Menu();
    }
}
