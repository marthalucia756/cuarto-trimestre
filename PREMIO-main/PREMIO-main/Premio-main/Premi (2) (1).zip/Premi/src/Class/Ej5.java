
package Class;


public class Ej5 extends Padre {

    @Override
    public void Imprimir() {
        
        if(num1 > 200){
            System.out.println("EL NUMERO ES MAYOR A 200");
        }else{
            System.out.println("EK NUMERO NO ES MAYOR A 200");
        }
    }
    
    
}
