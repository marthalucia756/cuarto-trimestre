
package Class;

public class Ej4 extends Padre {

    @Override
    public void Imprimir() {

        if (num1 >= 0) {
            System.out.println("EL NUMERO ES POSITIVO");
        } else {
            System.out.println("EL NUMERO ES NEGRO");
        }
    }
}
