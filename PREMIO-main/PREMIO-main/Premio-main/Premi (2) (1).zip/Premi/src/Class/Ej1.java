
package Class;

public class Ej1  extends Padre{
    
    @Override
    public void Imprimir(){
        if(num1 > 5 ){
         
            System.out.println("EL NUMERO ES MAYOR A 5");
        }else{
            System.out.println("EL NUMERO NO ES MAYOR A 5");
            
            
        }
        
        
    }
    
}


