
package Class;


public class Ej6 extends Padre {

    @Override
    public void Imprimir() {
        if(num1 >=50    &&  num1 <=100){
            System.out.println("EL NUMERO ESTA EN RANGO");
           
            
        }else{
            System.out.println("EL NUMERO NO ESTA EN RANGO");
        }
      
    }

}
