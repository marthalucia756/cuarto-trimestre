package Class;

public class Ej3 extends Padre {

    @Override
    public void Imprimir() {

        num1 = Math.abs(num1);
        System.out.println("EL VALOR ABS ES DE : "+ num1);
    }
}
