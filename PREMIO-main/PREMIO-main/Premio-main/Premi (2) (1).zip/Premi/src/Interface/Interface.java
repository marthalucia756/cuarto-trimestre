package Interface;

public interface Interface {

    void Ingresar();

    void Imprimir();

}
