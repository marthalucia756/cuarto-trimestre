package View;

import Class.Ej1;
import Class.Ej10;
import Class.Ej2;
import Class.Ej3;
import Class.Ej4;
import Class.Ej5;
import Class.Ej6;
import Class.Ej7;
import Class.Ej8;
import Class.Ej9;

public class Ejecutar {

    public static void main(String[] args) {
        Ej1 ej1 = new Ej1();
        ej1.Ingresar();
        ej1.Imprimir();

        Ej2 ej2 = new Ej2();
        ej2.Ingresar();
        ej2.Imprimir();

        Ej3 ej3 = new Ej3();
        ej3.Ingresar();
        ej3.Imprimir();

        Ej4 ej4 = new Ej4();
        ej4.Ingresar();
        ej4.Imprimir();

        Ej5 ej5 = new Ej5();
        ej5.Ingresar();
        ej5.Imprimir();

        Ej6 ej6 = new Ej6();
        ej6.Ingresar();
        ej6.Imprimir();

        Ej7 ej7 = new Ej7();
        ej7.Ingresar();
        ej7.Imprimir();

        Ej8 ej8 = new Ej8();
        ej8.Ingresar();
        ej8.Imprimir();

        Ej9 ej9 = new Ej9();
        ej9.Ingresar();
        ej9.Imprimir();

        Ej10 ej10 = new Ej10();
        ej10.Ingresar();
        ej10.Imprimir();

    }

}
